function selectFlights(id){
    $("#flight-selector").val(id);
}