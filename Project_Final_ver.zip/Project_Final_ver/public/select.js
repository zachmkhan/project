function selector(id, type){
    $("#" + type + "-selector").val(id);
}