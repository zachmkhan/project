function filterSQL(page) {
    //get the id of the selected table from the filter dropdown
    var filter_id = document.getElementById('filter').value
    window.location = '/' + page + '/filter/' +  encodeURI(filter_id)
}