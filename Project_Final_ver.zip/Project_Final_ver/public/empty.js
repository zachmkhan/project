function checkEmpty(){
	for(var i = 0; i < arguments.length; i++){
	    if(document.getElementById(arguments[i]).value.length == 0){
	    	return false;
	    }
	}
	return true;
}